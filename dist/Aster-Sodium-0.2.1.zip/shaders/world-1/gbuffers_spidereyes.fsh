#version 330 compatibility
#define ASTER_NETHER
#define ASTER_FRAGMENT
#define ASTER_ENTITY
#define ASTER_FORWARD
#define ASTER_EMISSIVE
#include "/lib/geometry.fsh"
